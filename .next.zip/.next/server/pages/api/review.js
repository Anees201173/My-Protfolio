"use strict";
(() => {
var exports = {};
exports.id = 514;
exports.ids = [514];
exports.modules = {

/***/ 3169:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
const review = [
    {
        id: 0,
        clientName: "Lucas Araujo",
        clientLocation: "Ireland",
        clientSource: "Fiverr",
        clientReview: "Extremally professional, very good communication skills and completely understood my needs. I highly recommend."
    },
    {
        id: 2,
        clientName: "salehthani",
        clientLocation: "Saudi Arabia",
        clientSource: "Fiverr",
        clientReview: "Great seller, great communication and quick response times, definitely going to work with them again"
    },
    {
        id: 3,
        clientName: "slyphid",
        clientLocation: "Singapore",
        clientSource: "Fiverr",
        clientReview: "Very excellent person to work with, was willing to edit and improve on the code whenever needed. Highly recommended."
    },
    {
        id: 4,
        clientName: "yosefwolday",
        clientLocation: "United States",
        clientSource: "Fiverr",
        clientReview: "Amazing communication and very clean code! The final product was exactly what I was looking for. I had an amazing experience working with Ali Akbar. I would recommend his services to anyone looking for work to be done."
    }
];
function handler(req, res) {
    res.status(200).json(review);
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(3169));
module.exports = __webpack_exports__;

})();